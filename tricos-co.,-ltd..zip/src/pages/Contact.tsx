import React from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

export const Contact = () => {
  const { t } = useTranslation();

  return (
    <div className="pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gradient">{t('contact.title')}</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Ready to take your business global? Contact our expert consultants today for a personalized strategy.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-12"
          >
            <div className="space-y-8">
              <div className="flex items-start space-x-6">
                <div className="p-4 bg-navy-900/30 rounded-xl text-navy-400">
                  <Mail size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Email Us</h3>
                  <p className="text-gray-400">info@tricos.co.kr</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="p-4 bg-navy-900/30 rounded-xl text-navy-400">
                  <Phone size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Call Us</h3>
                  <p className="text-gray-400">Office: 031-8014-2645</p>
                  <p className="text-gray-400">Fax: 031-8014-2646</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="p-4 bg-navy-900/30 rounded-xl text-navy-400">
                  <MapPin size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Visit Us</h3>
                  <p className="text-gray-400 leading-relaxed">
                    {t('contact.address')}
                  </p>
                </div>
              </div>
            </div>

            {/* Mock Map */}
            <div className="h-64 glass-card overflow-hidden relative">
              <div className="absolute inset-0 bg-navy-900/20 flex items-center justify-center">
                <span className="text-gray-500 font-medium">Google Maps Integration</span>
              </div>
              <img 
                src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&q=80&w=1000" 
                alt="Map Placeholder"
                className="w-full h-full object-cover opacity-30"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-card p-8 md:p-12"
          >
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">{t('contact.name')}</label>
                  <input
                    type="text"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-navy-500 transition-all"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">{t('contact.email')}</label>
                  <input
                    type="email"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-navy-500 transition-all"
                    placeholder="john@example.com"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Subject</label>
                <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-navy-500 transition-all appearance-none">
                  <option>Trade Consulting</option>
                  <option>Market Research</option>
                  <option>Export/Import Support</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">{t('contact.message')}</label>
                <textarea
                  rows={5}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-navy-500 transition-all"
                  placeholder="How can we help you?"
                />
              </div>
              <button className="w-full py-4 bg-navy-800 hover:bg-navy-700 text-white rounded-xl font-bold transition-all flex items-center justify-center group">
                {t('contact.send')}
                <Send className="ml-2 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" size={18} />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
};
